a = '''
./src/modelmerge/plugins
'''

print(len(a))  # 1911